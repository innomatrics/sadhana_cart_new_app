import 'package:flutter_riverpod/flutter_riverpod.dart';

final bottomNavigationBarIndex = StateProvider<int>((ref) => 0);
