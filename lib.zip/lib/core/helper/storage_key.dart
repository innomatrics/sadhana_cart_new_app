class StorageKey {
  static const String productsByCategoryKey = "productsByCategoryKey";
}
