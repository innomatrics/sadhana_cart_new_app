import 'package:flutter/widgets.dart';

final footWearTabTitle = const [" Description", "Details"];

final List<Widget> footWearTabBarTile = [];
