import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:sadhana_cart/core/helper/hive_helper.dart';

final authProvider = NotifierProvider<AuthNotifier, bool>(() => AuthNotifier());

class AuthNotifier extends Notifier<bool> {
  static String isLoggedInKey = 'isLoggedIn';
  @override
  bool build() {
    _loadLoginState();
    return false;
  }

  void _loadLoginState() async {
    final loggedIn = HiveHelper.getLocalData<bool>(key: isLoggedInKey) ?? false;
    state = loggedIn;
  }

  void login() async {
    await HiveHelper.storeLocalData<bool>(key: isLoggedInKey, value: true);
    state = true;
  }

  void setLoggedIn(bool value) {
    state = value;
  }

  void logout() async {
    await HiveHelper.storeLocalData<bool>(key: isLoggedInKey, value: false);
    state = false;
  }
}
